# CLAUDE.md - Claude Agentic Setup & Development Guide

This document defines the agentic workflow, automated quality gates, git hooks, and verification standards for Claude Code and AI coding assistants.

> ⚠️ **MANDATORY RULE**: This `CLAUDE.md` file MUST be updated at the end of **EVERY** completed task/step to reflect current milestone status, implemented handlers, and test execution details.

---

## 🚦 Milestone Task Progress Status

### Milestone 1: Safe Text/JSON Preview (100% RELEASED - v0.1.0 / v0.1.1 Hotfix)
- [x] **Task 1: Bootstrap & Integrity Documentation** (Completed)
- [x] **Task 2: Core Contracts & Manager** (`FileHandlerInterface`, `PreviewResult`, `FileInteractionManager`) (Completed)
- [x] **Task 3: Text Preview Handler** (`TextPreviewHandler` for `.txt` and `.md`) (Completed)
- [x] **Task 4: JSON Preview Handler** (`JsonPreviewHandler` for `.json`) (Completed)
- [x] **Task 5: File Validation Service** (`FileValidationService` for extension, path, size, MIME validation) (Completed)
- [x] **Task 6: Permission Service Abstraction** (`PermissionService`, `PermissionCheckerInterface`, `MockPermissionChecker`) (Completed)
- [x] **Task 7: Preview Controller & Route** (`FilePreviewController`, `FileContentFetcherInterface`) (Completed)
- [x] **Task 8: UI Entry Point Integration** (`Plugin.php` hooks, `Template/file/dropdown.php`, `Template/file/preview.php`) (Completed)
- [x] **Task 9: Automated Test Expansion** (`tests/Integration/PluginTest.php`, `tests/Unit/EdgeCasesTest.php`) (Completed)
- [x] **Task 10: Manual Checklist & Verification** (`docs/MANUAL_TESTING.md` matrix, 100% test pass rate verified) (Completed)

### Milestone 2: Safe CSV Read-Only Table Preview (100% RELEASED - v0.2.0)
- [x] **Task 11: Delimiter Detection & Parsing Service** (`CsvParserService` for `,`, `;`, `\t`, `|` detection) (Completed)
- [x] **Task 12: CSV Preview Handler** (`CsvParserService`, `CsvPreviewHandler` for `.csv` and `.tsv`) (Completed)
- [x] **Task 13: File Validation & Registry Expansion** (`FileValidationService`, `FileInteractionManager` name-based forced format, `FilePreviewController`) (Completed)
- [x] **Task 14: Responsive Safe CSV Table Template View** (`Template/file/csv_preview.php`, `FilePreviewController` template selection) (Completed)
- [x] **Task 15: Verification, Packaging & Release v0.2.0** (`CHANGELOG.md`, `dist/FileInteractionCore-0.2.0.zip`, 72 tests passing 100%) (Completed)

### Milestone 3: Safe Markdown HTML Rendering & Code Syntax Highlighting
- [x] **Task 16: Safe Markdown & Syntax Parser Service** (`MarkdownParserService` with XSS script entity escaping & link URI sanitization) (Completed)
- [x] **Task 17: Markdown Preview Handler** (`MarkdownPreviewHandler` for `.md` and `.markdown`) (Completed)
- [x] **Task 18: Code Syntax Highlighting Handler** (`CodePreviewHandler` for `.sh`, `.py`, `.js`, `.sql`, `.css`, `.php`, `.yml`, `.xml`) (Completed)
- [x] **Task 19: Template Views & Validation Registry Expansion** (`Template/file/markdown_preview.php`, `FileValidationService` +8 extensions, `FilePreviewController` 5-handler registry & template map, `Template/file/dropdown.php`) (Completed)
- [ ] **Task 20: Verification, Packaging & Release v0.3.0**

---

## 🛠️ Essential Commands & Agentic Scripts

```bash
# Automated Agent Verification Pipeline (PHP Syntax, Composer, PHPStan Level 8, 142 Tests Passing)
bash scripts/agent-verify.sh
# or via composer:
composer agent-verify

# Test Execution via Docker (PHP 8.1 container - 142 Tests Passing)
docker run --rm -v $(pwd):/app -w /app php:8.1-cli vendor/bin/phpunit

# Package Plugin Release v0.2.0
bash scripts/package-plugin.sh # or composer package

# Local Live Kanboard Test Instance
docker compose up -d # Accessible at http://localhost:8085 (admin/admin)
```

---

## 🤖 Agentic Development Lifecycle

Every task executed by Claude or AI agents follows a 6-phase loop:

1. **Intent & Spec Check**: Review `docs/specs/` and `docs/SECURITY.md` for target task boundaries.
2. **Plan & User Approval**: Formulate a small, reviewable implementation plan before touching code.
3. **Strict Code Implementation**:
   - PSR-12 coding standard with strict types (`declare(strict_types=1);`).
   - No Kanboard core modifications.
   - All plain-text output MUST be wrapped with `htmlspecialchars($str, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')`.
   - All input paths MUST be wrapped with `basename()`.
4. **Automated Unit Testing**: Write unit tests for every handler, service, and validator in `tests/Unit/`.
5. **Agentic Verification Pipeline**: Execute `bash scripts/agent-verify.sh` and run PHPUnit tests.
6. **Mandatory Documentation Update**: Update `CLAUDE.md` and `walkthrough.md` at the end of EVERY step.

---

## 📐 Architecture & Non-Negotiable Rules

1. **No Core Edits**: Never modify Kanboard core files. All functionality stays within this plugin.
2. **No Guessing**: Flag unverified APIs as `UNKNOWN` or `ASSUMPTION`.
3. **No Unescaped Output**: Always sanitize output to prevent XSS.
4. **Plan First**: Never write feature code without prior plan approval.
5. **Update CLAUDE.md Every Step**: Always update `CLAUDE.md` with new progress, handlers, and commands.

---

## 🧠 Lessons Learned & Agent Memory

1. **Host Environment Fallback**: If PHP/Composer binaries are absent on host CLI, `scripts/agent-verify.sh` automatically routes execution through Docker containers (`php:8.1-cli`, `composer:2`).
2. **Docker Workspace Permissions**: Files created or modified inside Docker containers inherit root/nginx ownership (`1000:100`). Run `docker run --rm -v $(pwd):/work alpine chown -R 1000:1000 /work` to reset file ownership to host user `$USER`.
3. **Kanboard `__isset()` Trap**: `Kanboard\Core\Base` implements magic `__get()` but NOT `__isset()`. Avoid `isset($this->serviceName)`; use container `offsetExists()` via `hasService()`.
4. **Kanboard Template Hook Naming**: Core Kanboard file dropdown hook names are `template:task-file:documents:dropdown` and `template:task-file:images:dropdown`.
5. **Safe Plain Text View**: For `.html`, `.yml`, `.env`, and `.json` attachments, output is strictly HTML-entity escaped (`htmlspecialchars()`) preventing browser script execution or DOM injection.
6. **CSV Modal View Dispatch**: `FilePreviewController` dispatches `FileInteractionCore:file/csv_preview` for CSV attachments, rendering responsive data tables with cell entity escaping and truncation notices.
7. **Markdown & Code Tokenizer**: `CodePreviewHandler` tokenizes code elements using placeholders before HTML span wrapping to prevent comment regexes matching CSS hex colors inside injected span attributes.
8. **Handler Registration Order Is Significant**: first match wins in `FileInteractionManager`. `TextPreviewHandler` accepts ANY `text/*` MIME type, so it MUST stay last; `CodePreviewHandler` also claims `.json`, so it MUST stay behind `JsonPreviewHandler` to preserve the pretty-printed JSON view. Registry order is `Csv → Markdown → Json → Code → Text`.
9. **Two Rendering Contracts**: `preview` / `csv_preview` receive entity-escaped text and escape again in the view. `markdown_preview` receives PRE-SANITIZED HTML from `MarkdownPreviewHandler` / `CodePreviewHandler` and MUST emit `$content` raw — wrapping it in `$this->text->e()` would display literal `&lt;h1&gt;` markup. All other template variables stay escaped.
10. **Script Extensions Are Previewable, Never Executed**: `.php`, `.js`, `.sh`, `.bash`, `.py` are whitelisted per spec 003 §2. `CodePreviewHandler` runs `htmlspecialchars()` over the entire payload BEFORE adding token spans, so the source is inert. `.svg` stays rejected — it is an active-content image format, not inert source text.
11. **Extension Must Reach The Handler**: `FilePreviewController` passes `['extension' => $extension]` into `preview()`; without it `CodePreviewHandler` labels every file as language `txt`.
12. **Templates Need Global `t()`**: plugin templates are global-namespace PHP files. Test-rendering them requires `tests/stubs/TemplateFunctions.php` — declaring `t()` inside a namespaced test case resolves to the wrong function.

---

## 🗂️ Preview Handler Registry & Template Dispatch

Resolution order (first match wins) as wired in `FilePreviewController::__construct`:

| # | Handler | Extensions | Template |
| :--- | :--- | :--- | :--- |
| 1 | `CsvPreviewHandler` | `.csv`, `.tsv` | `file/csv_preview` |
| 2 | `MarkdownPreviewHandler` | `.md`, `.markdown` | `file/markdown_preview` (raw HTML) |
| 3 | `JsonPreviewHandler` | `.json` | `file/preview` |
| 4 | `CodePreviewHandler` | `.yml`, `.yaml`, `.xml`, `.html`, `.htm`, `.sh`, `.bash`, `.py`, `.php`, `.js`, `.css`, `.sql` | `file/markdown_preview` (raw HTML) |
| 5 | `TextPreviewHandler` | `.txt`, `.env`, `.ini`, `.conf`, `.log` + any `text/*` fallback | `file/preview` |

> **Milestone 3 behavior change**: `.yml`, `.yaml`, `.xml`, `.html`, `.htm` moved from `TextPreviewHandler` to `CodePreviewHandler` (spec 003 AC-2). Output is still entity-escaped; it is now syntax highlighted.
