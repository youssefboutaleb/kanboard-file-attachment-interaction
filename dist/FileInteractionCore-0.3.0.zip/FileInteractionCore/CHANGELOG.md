# Changelog

All notable changes to `kanboard-file-interaction-core` will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.0] - 2026-08-08

### Added
- **Safe Markdown HTML Rendering Engine**:
  - `MarkdownParserService` & `MarkdownPreviewHandler` supporting `.md` and `.markdown` attachments.
  - Converts Markdown headers (`#`), lists (`-`/`1.`), blockquotes (`>`), bold/italic (`**`/`*`), code fences (```), and links into safe HTML.
  - Strict XSS script tag entity escaping (`<script>`, `<iframe>`, `<img onerror=...>`) and link protocol sanitization (`javascript:` -> `#`).
- **Code Syntax Highlighting Engine**:
  - `CodePreviewHandler` supporting `.json`, `.yml`, `.yaml`, `.xml`, `.html`, `.sh`, `.py`, `.php`, `.js`, `.css`, `.sql`.
  - Tokenized syntax highlighting for keywords, strings, comments, numbers, and functions with XSS entity escaping.
- **Rich HTML Preview Template**:
  - `Template/file/markdown_preview.php`: Shared rich modal view for Markdown & Code previews.
- **Expanded Test Suite**:
  - 70 new unit & integration tests covering Markdown parsing, link sanitization, syntax highlighting, options forwarding, and template dispatching (total 142 tests, 460 assertions).

### Changed
- Updated `FileValidationService` to whitelist `.markdown`, `.sh`, `.py`, `.php`, `.js`, `.css`, `.sql` extensions and MIME maps.
- Updated `FileInteractionManager` & `FilePreviewController` to register 5 format handlers (`MarkdownPreviewHandler`, `CsvPreviewHandler`, `CodePreviewHandler`, `JsonPreviewHandler`, `TextPreviewHandler`).

---

## [0.2.0] - 2026-08-08

### Added
- **CSV & TSV Read-Only Table Preview Engine**:
  - `CsvPreviewHandler`: Format handler supporting `.csv` and `.tsv` attachments.
  - `CsvParserService`: Memory-safe streaming parser supporting comma (`,`), semicolon (`;`), tab (`\t`), and pipe (`|`) field delimiters.
  - Automatic delimiter detection based on frequency scoring across head lines.
  - HTML entity escaping (`htmlspecialchars()`) applied to all CSV cell values to prevent XSS.
  - Preview bounds capping output to first 100 rows and 50 columns to guarantee fast rendering under 8MB RAM.
  - `Template/file/csv_preview.php`: Responsive modal table template view with styled headers, alternating row colors, row index column, delimiter badge, and truncation warning banners.
- **Test Suite Expansion**:
  - 18 new unit & integration tests covering CSV delimiter detection, table rendering, truncation limits, cell XSS escaping, and DIC container resolution (total 72 tests, 240 assertions).

### Changed
- Updated `FileValidationService` to whitelist `csv` and `tsv` extensions and MIME types (`text/csv`, `text/tab-separated-values`, `application/vnd.ms-excel`).
- Updated `FileInteractionManager` to support name-based forced format resolution.
- Updated `FilePreviewController` to route CSV previews to `FileInteractionCore:file/csv_preview`.

---

## [0.1.0] - 2026-08-07

### Added
- **Core Strategy & Registry Architecture**:
  - `FileHandlerInterface` contract for file preview handlers.
  - `PreviewResult` immutable value object for preview output and metadata.
  - `FileInteractionManager` central registry for format handler resolution and forced format overrides.
- **Format Handlers**:
  - `TextPreviewHandler`: Safe read-only preview for `.txt`, `.md`, `.env`, `.ini`, `.conf`, `.yaml`, `.yml`, `.xml`, `.log`, `.html`, `.htm`.
  - `JsonPreviewHandler`: Safe JSON validation, 2-space pretty printing, recursion depth limit (500 KB / 512 depth), and friendly invalid JSON error reporting.
- **Security & Validation Services**:
  - `FileValidationService`: Strict extension whitelisting, `basename()` path traversal protection, null-byte rejection, 500 KB file size limit enforcement, and MIME type validation.
  - `PermissionService` & `PermissionCheckerInterface`: ACL authorization abstraction for project, task, and file read access.
  - `MockPermissionChecker`: In-memory permission checker for decoupled unit testing.
- **UI Integration & Controllers**:
  - `FilePreviewController`: Handles preview route requests `/b/:project_id/task/:task_id/file/:file_id/preview`.
  - `Template/file/dropdown.php`: Injects "Safe Preview" modal action link into task attachment dropdown menus.
  - `Template/file/preview.php`: Renders modal preview dialog displaying filename, handler badge, line/char counts, and HTML-escaped content.
- **Agentic Infrastructure & Quality Gates**:
  - `scripts/agent-verify.sh`: Verification script running PHP syntax check, composer validation, PHPStan Level 8 static analysis, and PHPUnit unit tests (with automatic Docker fallback).
  - `.githooks/pre-commit` & `.githooks/pre-push`: Automated git pre-commit and pre-push security hooks.
  - `docker-compose.yml`: Live Kanboard testing environment mapped to port `8085`.
  - `scripts/package-plugin.sh`: Packaging script for building release ZIP archives (`dist/FileInteractionCore-0.1.0.zip`).
- **Comprehensive Documentation**:
  - `AGENTS.md`, `CLAUDE.md`, `SECURITY.md`, `ARCHITECTURE.md`, `ROADMAP.md`, `docs/specs/001-safe-text-preview.md`, and `docs/MANUAL_TESTING.md`.
