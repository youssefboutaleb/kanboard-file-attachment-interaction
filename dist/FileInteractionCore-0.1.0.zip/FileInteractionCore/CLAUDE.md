# CLAUDE.md - Claude Agentic Setup & Development Guide

This document defines the agentic workflow, automated quality gates, git hooks, and verification standards for Claude Code and AI coding assistants.

> ⚠️ **MANDATORY RULE**: This `CLAUDE.md` file MUST be updated at the end of **EVERY** completed task/step to reflect current milestone status, implemented handlers, and test execution details.

---

## 🚦 Milestone 1 Task Progress Status (100% RELEASED - v0.1.0)

- [x] **Task 1: Bootstrap & Integrity Documentation** (Completed)
- [x] **Task 2: Core Contracts & Manager** (`FileHandlerInterface`, `PreviewResult`, `FileInteractionManager`) (Completed)
- [x] **Task 3: Text Preview Handler** (`TextPreviewHandler` for `.txt` and `.md`) (Completed)
- [x] **Task 4: JSON Preview Handler** (`JsonPreviewHandler` for `.json`) (Completed)
- [x] **Task 5: File Validation Service** (`FileValidationService` for extension, path, size, MIME validation) (Completed)
- [x] **Task 6: Permission Service Abstraction** (`PermissionService`, `PermissionCheckerInterface`, `MockPermissionChecker`) (Completed)
- [x] **Task 7: Preview Controller & Route** (`FilePreviewController`, `FileContentFetcherInterface`) (Completed)
- [x] **Task 8: UI Entry Point Integration** (`Plugin.php` hooks, `Template/file/dropdown.php`, `Template/file/preview.php`) (Completed)
- [x] **Task 9: Automated Test Expansion** (`tests/Integration/PluginTest.php`, `tests/Unit/EdgeCasesTest.php` - 37 Tests Passing) (Completed)
- [x] **Task 10: Manual Checklist & Verification** (`docs/MANUAL_TESTING.md` matrix, 100% test pass rate verified) (Completed)

---

## 🩹 Milestone 1 Hotfix Status (v0.1.1 - Browser Runtime Repair)

- [x] **Task 11: Live Browser Preview Defect Diagnosis & Fix** (Completed)
  - **Symptom**: Clicking *Safe Preview* opened an empty modal; endpoint returned `HTTP 200` with **0 bytes**.
  - **Root Cause**: `Kanboard\Core\Base` implements `__get()` but **not** `__isset()`, so every
    `isset($this->request)` / `isset($this->response)` / `isset($this->template)` guard in
    `FilePreviewController::show()` evaluated to `false` at runtime. Request parameters were never
    read (all IDs fell back to `0`) and the render branch was permanently dead code.
  - **Fix**: `FilePreviewController::hasService()` now probes the Pimple container via `ArrayAccess`.
  - **Verified**: 8 attachments (`.json`, `.html`, `.yml`, `.env`, `.md`) return `HTTP 200` with full
    modal HTML on both the pretty route and the query-string route; 0 PHP notices in container logs.

---

## 🛠️ Essential Commands & Agentic Scripts

```bash
# Automated Agent Verification Pipeline (PHP Syntax, Composer, PHPStan Level 8, 44 Tests Passing)
bash scripts/agent-verify.sh
# or via composer:
composer agent-verify

# Test Execution via Docker (PHP 8.1 container - 44 Tests Passing)
docker run --rm -v $(pwd):/app -w /app php:8.1-cli vendor/bin/phpunit

# Reset workspace ownership after ANY container start/restart (see Lesson 2)
docker run --rm -v $(pwd):/work alpine chown -R 1000:1000 /work

# Package Plugin Release
bash scripts/package-plugin.sh # or composer package

# Local Live Kanboard Test Instance
docker compose up -d # Accessible at http://localhost:8085 (admin/admin)
```

---

## 🤖 Agentic Development Lifecycle

Every task executed by Claude or AI agents follows a 6-phase loop:

1. **Intent & Spec Check**: Review `docs/specs/` and `docs/SECURITY.md` for target task boundaries.
2. **Plan & User Approval**: Formulate a small, reviewable implementation plan before touching code.
3. **Strict Code Implementation**:
   - PSR-12 coding standard with strict types (`declare(strict_types=1);`).
   - No Kanboard core modifications.
   - All plain-text output MUST be wrapped with `htmlspecialchars($str, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')`.
   - All input paths MUST be wrapped with `basename()`.
4. **Automated Unit Testing**: Write unit tests for every handler, service, and validator in `tests/Unit/`.
5. **Agentic Verification Pipeline**: Execute `bash scripts/agent-verify.sh` and run PHPUnit tests.
6. **Mandatory Documentation Update**: Update `CLAUDE.md` and `walkthrough.md` at the end of EVERY step.

---

## 📐 Architecture & Non-Negotiable Rules

1. **No Core Edits**: Never modify Kanboard core files. All functionality stays within this plugin.
2. **No Guessing**: Flag unverified APIs as `UNKNOWN` or `ASSUMPTION`.
3. **No Unescaped Output**: Always sanitize output to prevent XSS.
4. **Plan First**: Never write feature code without prior plan approval.
5. **Update CLAUDE.md Every Step**: Always update `CLAUDE.md` with new progress, handlers, and commands.

---

## 🧠 Lessons Learned & Agent Memory

1. **Host Environment Fallback**: If PHP/Composer binaries are absent on host CLI, `scripts/agent-verify.sh` automatically routes execution through Docker containers (`php:8.1-cli`, `composer:2`).
2. **Docker Workspace Permissions**: The Kanboard image's `/entrypoint.sh` runs `chown -R nginx:nginx /var/www/app/plugins` on **every container start**, so `docker compose up/restart` silently re-owns this bind-mounted workspace to `100:101` and host edits start failing with `EACCES`. Re-run `docker run --rm -v $(pwd):/work alpine chown -R 1000:1000 /work` after **every** restart.
3. **Kanboard Template Hook Naming**: Core Kanboard file dropdown hook names are `template:task-file:documents:dropdown` and `template:task-file:images:dropdown` (hyphenated `task-file`). The project overview only exposes `template:project-overview:documents:dropdown` — there is **no** `:images:` variant, and it passes `project` + `file` (never `task`).
4. **Kanboard Base Class & File Loading**: `FilePreviewController` extends `Kanboard\Controller\BaseController` and uses `$this->taskFileModel->getById()` + `$this->objectStorage->get($file['path'])` to retrieve binary attachment content cleanly.
5. **Safe Plain Text View**: For `.html`, `.yml`, `.env`, and `.json` attachments, output is strictly HTML-entity escaped (`htmlspecialchars()`) preventing browser script execution or DOM injection.
6. **🚨 `Kanboard\Core\Base` has `__get()` but NO `__isset()`**: Therefore `isset($this->request)`, `isset($this->response)`, `isset($this->template)` and `empty($this->anyService)` are **ALWAYS FALSE** inside any controller, even when the service exists. Never use `isset()` to detect the Kanboard HTTP runtime context — probe the container instead (`$this->container instanceof \ArrayAccess && $this->container->offsetExists($name)`). This exact trap produced a silent `HTTP 200` + 0-byte empty preview modal.
7. **Modal Helper Icon Argument**: `$this->modal->medium($icon, ...)` takes a **bare** FontAwesome name (`'eye'`), which it expands to `fa fa-eye`. Passing `'icon-eye'` renders the non-existent class `fa fa-icon-eye`.
8. **Plugin URL Resolution**: A route registered via `$this->route->addRoute()` makes Kanboard's URL helper emit the *pretty* path (`/b/1/task/1/file/5/preview`) instead of the query-string form. Always smoke-test **both** URL shapes.
9. **Testing the Runtime Path**: `tests/stubs/BaseController.php` deliberately mirrors core by implementing `__get()` **without** `__isset()`. Do not add `__isset()` to it — that asymmetry is what makes `tests/Unit/FilePreviewControllerRuntimeTest.php` able to catch Lesson 6 regressions.
